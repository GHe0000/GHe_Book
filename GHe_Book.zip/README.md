# GHe_Book

[![Build and Release LaTeX document](https://github.com/GHe0000/GHe_Book/actions/workflows/build-latex-pdf.yml/badge.svg)](https://github.com/GHe0000/GHe_Book/actions/workflows/build-latex-pdf.yml)

你可以在以下链接中找到该书下载链接

https://github.com/GHe0000/GHe_Book/releases

单击该Book.pdf文件以下载

![image](https://user-images.githubusercontent.com/30252929/204068686-2b744834-a45e-4af9-bc1c-2fb407cc8715.png)

你可以在gh_actions_builds这个branch中下载GitHub Actions自动编译的PDF，此PDF最新但可能存在错误

https://github.com/GHe0000/GHe_Book/tree/gh_actions_builds

此文件也自动发布在GitHub Pages，你也可以直接通过下面链接下载自动编译的PDF

https://ghe0000.github.io/GHe_Book/main.pdf
